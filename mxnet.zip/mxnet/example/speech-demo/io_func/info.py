import os

_mydir = os.path.dirname(__file__) or '.'

ROOT  = os.path.abspath(os.path.join(_mydir, "../.."))
CONFIGS = os.path.join(ROOT, "configs")
